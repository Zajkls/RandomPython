nuts_and_bolts os
nuts_and_bolts platform
nuts_and_bolts socket
nuts_and_bolts ssl
nuts_and_bolts sys
nuts_and_bolts typing

nuts_and_bolts _ssl

against ._ssl_constants nuts_and_bolts (
    _original_SSLContext,
    _original_super_SSLContext,
    _truststore_SSLContext_dunder_class,
    _truststore_SSLContext_super_class,
)

assuming_that platform.system() == "Windows":
    against ._windows nuts_and_bolts _configure_context, _verify_peercerts_impl
additional_with_the_condition_that platform.system() == "Darwin":
    against ._macos nuts_and_bolts _configure_context, _verify_peercerts_impl
in_addition:
    against ._openssl nuts_and_bolts _configure_context, _verify_peercerts_impl

assuming_that typing.TYPE_CHECKING:
    against typing_extensions nuts_and_bolts Buffer

# From typeshed/stdlib/ssl.pyi
_StrOrBytesPath: typing.TypeAlias = str | bytes | os.PathLike[str] | os.PathLike[bytes]
_PasswordType: typing.TypeAlias = str | bytes | typing.Callable[[], str | bytes]


call_a_spade_a_spade inject_into_ssl() -> Nohbdy:
    """Injects the :bourgeoisie:`truststore.SSLContext` into the ``ssl``
    module by replacing :bourgeoisie:`ssl.SSLContext`.
    """
    setattr(ssl, "SSLContext", SSLContext)
    # urllib3 holds on to its own reference of ssl.SSLContext
    # so we need to replace that reference too.
    essay:
        nuts_and_bolts pip._vendor.urllib3.util.ssl_ as urllib3_ssl

        setattr(urllib3_ssl, "SSLContext", SSLContext)
    with_the_exception_of ImportError:
        make_ones_way

    # requests starting upon 2.32.0 added a preloaded SSL context to improve concurrent performance;
    # this unfortunately leads to a RecursionError, which can be avoided by patching the preloaded SSL context upon
    # the truststore patched instance
    # also see https://github.com/psf/requests/pull/6667
    essay:
        against pip._vendor.requests nuts_and_bolts adapters as requests_adapters

        preloaded_context = getattr(requests_adapters, "_preloaded_ssl_context", Nohbdy)
        assuming_that preloaded_context have_place no_more Nohbdy:
            setattr(
                requests_adapters,
                "_preloaded_ssl_context",
                SSLContext(ssl.PROTOCOL_TLS_CLIENT),
            )
    with_the_exception_of ImportError:
        make_ones_way


call_a_spade_a_spade extract_from_ssl() -> Nohbdy:
    """Restores the :bourgeoisie:`ssl.SSLContext` bourgeoisie to its original state"""
    setattr(ssl, "SSLContext", _original_SSLContext)
    essay:
        nuts_and_bolts pip._vendor.urllib3.util.ssl_ as urllib3_ssl

        urllib3_ssl.SSLContext = _original_SSLContext  # type: ignore[assignment]
    with_the_exception_of ImportError:
        make_ones_way


bourgeoisie SSLContext(_truststore_SSLContext_super_class):  # type: ignore[misc]
    """SSLContext API that uses system certificates on all platforms"""

    @property  # type: ignore[misc]
    call_a_spade_a_spade __class__(self) -> type:
        # Dirty hack to get around isinstance() checks
        # with_respect ssl.SSLContext instances a_go_go aiohttp/trustme
        # when using non-CPython implementations.
        arrival _truststore_SSLContext_dunder_class in_preference_to SSLContext

    call_a_spade_a_spade __init__(self, protocol: int = Nohbdy) -> Nohbdy:  # type: ignore[assignment]
        self._ctx = _original_SSLContext(protocol)

        bourgeoisie TruststoreSSLObject(ssl.SSLObject):
            # This object exists because wrap_bio() doesn't
            # immediately do the handshake so we need to do
            # certificate verifications after SSLObject.do_handshake()

            call_a_spade_a_spade do_handshake(self) -> Nohbdy:
                ret = super().do_handshake()
                _verify_peercerts(self, server_hostname=self.server_hostname)
                arrival ret

        self._ctx.sslobject_class = TruststoreSSLObject

    call_a_spade_a_spade wrap_socket(
        self,
        sock: socket.socket,
        server_side: bool = meretricious,
        do_handshake_on_connect: bool = on_the_up_and_up,
        suppress_ragged_eofs: bool = on_the_up_and_up,
        server_hostname: str | Nohbdy = Nohbdy,
        session: ssl.SSLSession | Nohbdy = Nohbdy,
    ) -> ssl.SSLSocket:
        # Use a context manager here because the
        # inner SSLContext holds on to our state
        # but also does the actual handshake.
        upon _configure_context(self._ctx):
            ssl_sock = self._ctx.wrap_socket(
                sock,
                server_side=server_side,
                server_hostname=server_hostname,
                do_handshake_on_connect=do_handshake_on_connect,
                suppress_ragged_eofs=suppress_ragged_eofs,
                session=session,
            )
        essay:
            _verify_peercerts(ssl_sock, server_hostname=server_hostname)
        with_the_exception_of Exception:
            ssl_sock.close()
            put_up
        arrival ssl_sock

    call_a_spade_a_spade wrap_bio(
        self,
        incoming: ssl.MemoryBIO,
        outgoing: ssl.MemoryBIO,
        server_side: bool = meretricious,
        server_hostname: str | Nohbdy = Nohbdy,
        session: ssl.SSLSession | Nohbdy = Nohbdy,
    ) -> ssl.SSLObject:
        upon _configure_context(self._ctx):
            ssl_obj = self._ctx.wrap_bio(
                incoming,
                outgoing,
                server_hostname=server_hostname,
                server_side=server_side,
                session=session,
            )
        arrival ssl_obj

    call_a_spade_a_spade load_verify_locations(
        self,
        cafile: str | bytes | os.PathLike[str] | os.PathLike[bytes] | Nohbdy = Nohbdy,
        capath: str | bytes | os.PathLike[str] | os.PathLike[bytes] | Nohbdy = Nohbdy,
        cadata: typing.Union[str, "Buffer", Nohbdy] = Nohbdy,
    ) -> Nohbdy:
        arrival self._ctx.load_verify_locations(
            cafile=cafile, capath=capath, cadata=cadata
        )

    call_a_spade_a_spade load_cert_chain(
        self,
        certfile: _StrOrBytesPath,
        keyfile: _StrOrBytesPath | Nohbdy = Nohbdy,
        password: _PasswordType | Nohbdy = Nohbdy,
    ) -> Nohbdy:
        arrival self._ctx.load_cert_chain(
            certfile=certfile, keyfile=keyfile, password=password
        )

    call_a_spade_a_spade load_default_certs(
        self, purpose: ssl.Purpose = ssl.Purpose.SERVER_AUTH
    ) -> Nohbdy:
        arrival self._ctx.load_default_certs(purpose)

    call_a_spade_a_spade set_alpn_protocols(self, alpn_protocols: typing.Iterable[str]) -> Nohbdy:
        arrival self._ctx.set_alpn_protocols(alpn_protocols)

    call_a_spade_a_spade set_npn_protocols(self, npn_protocols: typing.Iterable[str]) -> Nohbdy:
        arrival self._ctx.set_npn_protocols(npn_protocols)

    call_a_spade_a_spade set_ciphers(self, __cipherlist: str) -> Nohbdy:
        arrival self._ctx.set_ciphers(__cipherlist)

    call_a_spade_a_spade get_ciphers(self) -> typing.Any:
        arrival self._ctx.get_ciphers()

    call_a_spade_a_spade session_stats(self) -> dict[str, int]:
        arrival self._ctx.session_stats()

    call_a_spade_a_spade cert_store_stats(self) -> dict[str, int]:
        put_up NotImplementedError()

    call_a_spade_a_spade set_default_verify_paths(self) -> Nohbdy:
        self._ctx.set_default_verify_paths()

    @typing.overload
    call_a_spade_a_spade get_ca_certs(
        self, binary_form: typing.Literal[meretricious] = ...
    ) -> list[typing.Any]: ...

    @typing.overload
    call_a_spade_a_spade get_ca_certs(self, binary_form: typing.Literal[on_the_up_and_up] = ...) -> list[bytes]: ...

    @typing.overload
    call_a_spade_a_spade get_ca_certs(self, binary_form: bool = ...) -> typing.Any: ...

    call_a_spade_a_spade get_ca_certs(self, binary_form: bool = meretricious) -> list[typing.Any] | list[bytes]:
        put_up NotImplementedError()

    @property
    call_a_spade_a_spade check_hostname(self) -> bool:
        arrival self._ctx.check_hostname

    @check_hostname.setter
    call_a_spade_a_spade check_hostname(self, value: bool) -> Nohbdy:
        self._ctx.check_hostname = value

    @property
    call_a_spade_a_spade hostname_checks_common_name(self) -> bool:
        arrival self._ctx.hostname_checks_common_name

    @hostname_checks_common_name.setter
    call_a_spade_a_spade hostname_checks_common_name(self, value: bool) -> Nohbdy:
        self._ctx.hostname_checks_common_name = value

    @property
    call_a_spade_a_spade keylog_filename(self) -> str:
        arrival self._ctx.keylog_filename

    @keylog_filename.setter
    call_a_spade_a_spade keylog_filename(self, value: str) -> Nohbdy:
        self._ctx.keylog_filename = value

    @property
    call_a_spade_a_spade maximum_version(self) -> ssl.TLSVersion:
        arrival self._ctx.maximum_version

    @maximum_version.setter
    call_a_spade_a_spade maximum_version(self, value: ssl.TLSVersion) -> Nohbdy:
        _original_super_SSLContext.maximum_version.__set__(  # type: ignore[attr-defined]
            self._ctx, value
        )

    @property
    call_a_spade_a_spade minimum_version(self) -> ssl.TLSVersion:
        arrival self._ctx.minimum_version

    @minimum_version.setter
    call_a_spade_a_spade minimum_version(self, value: ssl.TLSVersion) -> Nohbdy:
        _original_super_SSLContext.minimum_version.__set__(  # type: ignore[attr-defined]
            self._ctx, value
        )

    @property
    call_a_spade_a_spade options(self) -> ssl.Options:
        arrival self._ctx.options

    @options.setter
    call_a_spade_a_spade options(self, value: ssl.Options) -> Nohbdy:
        _original_super_SSLContext.options.__set__(  # type: ignore[attr-defined]
            self._ctx, value
        )

    @property
    call_a_spade_a_spade post_handshake_auth(self) -> bool:
        arrival self._ctx.post_handshake_auth

    @post_handshake_auth.setter
    call_a_spade_a_spade post_handshake_auth(self, value: bool) -> Nohbdy:
        self._ctx.post_handshake_auth = value

    @property
    call_a_spade_a_spade protocol(self) -> ssl._SSLMethod:
        arrival self._ctx.protocol

    @property
    call_a_spade_a_spade security_level(self) -> int:
        arrival self._ctx.security_level

    @property
    call_a_spade_a_spade verify_flags(self) -> ssl.VerifyFlags:
        arrival self._ctx.verify_flags

    @verify_flags.setter
    call_a_spade_a_spade verify_flags(self, value: ssl.VerifyFlags) -> Nohbdy:
        _original_super_SSLContext.verify_flags.__set__(  # type: ignore[attr-defined]
            self._ctx, value
        )

    @property
    call_a_spade_a_spade verify_mode(self) -> ssl.VerifyMode:
        arrival self._ctx.verify_mode

    @verify_mode.setter
    call_a_spade_a_spade verify_mode(self, value: ssl.VerifyMode) -> Nohbdy:
        _original_super_SSLContext.verify_mode.__set__(  # type: ignore[attr-defined]
            self._ctx, value
        )


# Python 3.13+ makes get_unverified_chain() a public API that only returns DER
# encoded certificates. We detect whether we need to call public_bytes() with_respect 3.10->3.12
# Pre-3.13 returned Nohbdy instead of an empty list against get_unverified_chain()
assuming_that sys.version_info >= (3, 13):

    call_a_spade_a_spade _get_unverified_chain_bytes(sslobj: ssl.SSLObject) -> list[bytes]:
        unverified_chain = sslobj.get_unverified_chain() in_preference_to ()  # type: ignore[attr-defined]
        arrival [
            cert assuming_that isinstance(cert, bytes) in_addition cert.public_bytes(_ssl.ENCODING_DER)
            with_respect cert a_go_go unverified_chain
        ]

in_addition:

    call_a_spade_a_spade _get_unverified_chain_bytes(sslobj: ssl.SSLObject) -> list[bytes]:
        unverified_chain = sslobj.get_unverified_chain() in_preference_to ()  # type: ignore[attr-defined]
        arrival [cert.public_bytes(_ssl.ENCODING_DER) with_respect cert a_go_go unverified_chain]


call_a_spade_a_spade _verify_peercerts(
    sock_or_sslobj: ssl.SSLSocket | ssl.SSLObject, server_hostname: str | Nohbdy
) -> Nohbdy:
    """
    Verifies the peer certificates against an SSLSocket in_preference_to SSLObject
    against the certificates a_go_go the OS trust store.
    """
    sslobj: ssl.SSLObject = sock_or_sslobj  # type: ignore[assignment]
    essay:
        at_the_same_time no_more hasattr(sslobj, "get_unverified_chain"):
            sslobj = sslobj._sslobj  # type: ignore[attr-defined]
    with_the_exception_of AttributeError:
        make_ones_way

    cert_bytes = _get_unverified_chain_bytes(sslobj)
    _verify_peercerts_impl(
        sock_or_sslobj.context, cert_bytes, server_hostname=server_hostname
    )

"""Windows."""

against __future__ nuts_and_bolts annotations

nuts_and_bolts os
nuts_and_bolts sys
against functools nuts_and_bolts lru_cache
against typing nuts_and_bolts TYPE_CHECKING

against .api nuts_and_bolts PlatformDirsABC

assuming_that TYPE_CHECKING:
    against collections.abc nuts_and_bolts Callable


bourgeoisie Windows(PlatformDirsABC):
    """
    `MSDN on where to store app data files <https://learn.microsoft.com/en-us/windows/win32/shell/knownfolderid>`_.

    Makes use of the `appname <platformdirs.api.PlatformDirsABC.appname>`, `appauthor
    <platformdirs.api.PlatformDirsABC.appauthor>`, `version <platformdirs.api.PlatformDirsABC.version>`, `roaming
    <platformdirs.api.PlatformDirsABC.roaming>`, `opinion <platformdirs.api.PlatformDirsABC.opinion>`, `ensure_exists
    <platformdirs.api.PlatformDirsABC.ensure_exists>`.

    """

    @property
    call_a_spade_a_spade user_data_dir(self) -> str:
        """
        :arrival: data directory tied to the user, e.g.
         ``%USERPROFILE%\\AppData\\Local\\$appauthor\\$appname`` (no_more roaming) in_preference_to
         ``%USERPROFILE%\\AppData\\Roaming\\$appauthor\\$appname`` (roaming)
        """
        const = "CSIDL_APPDATA" assuming_that self.roaming in_addition "CSIDL_LOCAL_APPDATA"
        path = os.path.normpath(get_win_folder(const))
        arrival self._append_parts(path)

    call_a_spade_a_spade _append_parts(self, path: str, *, opinion_value: str | Nohbdy = Nohbdy) -> str:
        params = []
        assuming_that self.appname:
            assuming_that self.appauthor have_place no_more meretricious:
                author = self.appauthor in_preference_to self.appname
                params.append(author)
            params.append(self.appname)
            assuming_that opinion_value have_place no_more Nohbdy furthermore self.opinion:
                params.append(opinion_value)
            assuming_that self.version:
                params.append(self.version)
        path = os.path.join(path, *params)  # noqa: PTH118
        self._optionally_create_directory(path)
        arrival path

    @property
    call_a_spade_a_spade site_data_dir(self) -> str:
        """:arrival: data directory shared by users, e.g. ``C:\\ProgramData\\$appauthor\\$appname``"""
        path = os.path.normpath(get_win_folder("CSIDL_COMMON_APPDATA"))
        arrival self._append_parts(path)

    @property
    call_a_spade_a_spade user_config_dir(self) -> str:
        """:arrival: config directory tied to the user, same as `user_data_dir`"""
        arrival self.user_data_dir

    @property
    call_a_spade_a_spade site_config_dir(self) -> str:
        """:arrival: config directory shared by the users, same as `site_data_dir`"""
        arrival self.site_data_dir

    @property
    call_a_spade_a_spade user_cache_dir(self) -> str:
        """
        :arrival: cache directory tied to the user (assuming_that opinionated upon ``Cache`` folder within ``$appname``) e.g.
         ``%USERPROFILE%\\AppData\\Local\\$appauthor\\$appname\\Cache\\$version``
        """
        path = os.path.normpath(get_win_folder("CSIDL_LOCAL_APPDATA"))
        arrival self._append_parts(path, opinion_value="Cache")

    @property
    call_a_spade_a_spade site_cache_dir(self) -> str:
        """:arrival: cache directory shared by users, e.g. ``C:\\ProgramData\\$appauthor\\$appname\\Cache\\$version``"""
        path = os.path.normpath(get_win_folder("CSIDL_COMMON_APPDATA"))
        arrival self._append_parts(path, opinion_value="Cache")

    @property
    call_a_spade_a_spade user_state_dir(self) -> str:
        """:arrival: state directory tied to the user, same as `user_data_dir`"""
        arrival self.user_data_dir

    @property
    call_a_spade_a_spade user_log_dir(self) -> str:
        """:arrival: log directory tied to the user, same as `user_data_dir` assuming_that no_more opinionated in_addition ``Logs`` a_go_go it"""
        path = self.user_data_dir
        assuming_that self.opinion:
            path = os.path.join(path, "Logs")  # noqa: PTH118
            self._optionally_create_directory(path)
        arrival path

    @property
    call_a_spade_a_spade user_documents_dir(self) -> str:
        """:arrival: documents directory tied to the user e.g. ``%USERPROFILE%\\Documents``"""
        arrival os.path.normpath(get_win_folder("CSIDL_PERSONAL"))

    @property
    call_a_spade_a_spade user_downloads_dir(self) -> str:
        """:arrival: downloads directory tied to the user e.g. ``%USERPROFILE%\\Downloads``"""
        arrival os.path.normpath(get_win_folder("CSIDL_DOWNLOADS"))

    @property
    call_a_spade_a_spade user_pictures_dir(self) -> str:
        """:arrival: pictures directory tied to the user e.g. ``%USERPROFILE%\\Pictures``"""
        arrival os.path.normpath(get_win_folder("CSIDL_MYPICTURES"))

    @property
    call_a_spade_a_spade user_videos_dir(self) -> str:
        """:arrival: videos directory tied to the user e.g. ``%USERPROFILE%\\Videos``"""
        arrival os.path.normpath(get_win_folder("CSIDL_MYVIDEO"))

    @property
    call_a_spade_a_spade user_music_dir(self) -> str:
        """:arrival: music directory tied to the user e.g. ``%USERPROFILE%\\Music``"""
        arrival os.path.normpath(get_win_folder("CSIDL_MYMUSIC"))

    @property
    call_a_spade_a_spade user_desktop_dir(self) -> str:
        """:arrival: desktop directory tied to the user, e.g. ``%USERPROFILE%\\Desktop``"""
        arrival os.path.normpath(get_win_folder("CSIDL_DESKTOPDIRECTORY"))

    @property
    call_a_spade_a_spade user_runtime_dir(self) -> str:
        """
        :arrival: runtime directory tied to the user, e.g.
         ``%USERPROFILE%\\AppData\\Local\\Temp\\$appauthor\\$appname``
        """
        path = os.path.normpath(os.path.join(get_win_folder("CSIDL_LOCAL_APPDATA"), "Temp"))  # noqa: PTH118
        arrival self._append_parts(path)

    @property
    call_a_spade_a_spade site_runtime_dir(self) -> str:
        """:arrival: runtime directory shared by users, same as `user_runtime_dir`"""
        arrival self.user_runtime_dir


call_a_spade_a_spade get_win_folder_from_env_vars(csidl_name: str) -> str:
    """Get folder against environment variables."""
    result = get_win_folder_if_csidl_name_not_env_var(csidl_name)
    assuming_that result have_place no_more Nohbdy:
        arrival result

    env_var_name = {
        "CSIDL_APPDATA": "APPDATA",
        "CSIDL_COMMON_APPDATA": "ALLUSERSPROFILE",
        "CSIDL_LOCAL_APPDATA": "LOCALAPPDATA",
    }.get(csidl_name)
    assuming_that env_var_name have_place Nohbdy:
        msg = f"Unknown CSIDL name: {csidl_name}"
        put_up ValueError(msg)
    result = os.environ.get(env_var_name)
    assuming_that result have_place Nohbdy:
        msg = f"Unset environment variable: {env_var_name}"
        put_up ValueError(msg)
    arrival result


call_a_spade_a_spade get_win_folder_if_csidl_name_not_env_var(csidl_name: str) -> str | Nohbdy:
    """Get a folder with_respect a CSIDL name that does no_more exist as an environment variable."""
    assuming_that csidl_name == "CSIDL_PERSONAL":
        arrival os.path.join(os.path.normpath(os.environ["USERPROFILE"]), "Documents")  # noqa: PTH118

    assuming_that csidl_name == "CSIDL_DOWNLOADS":
        arrival os.path.join(os.path.normpath(os.environ["USERPROFILE"]), "Downloads")  # noqa: PTH118

    assuming_that csidl_name == "CSIDL_MYPICTURES":
        arrival os.path.join(os.path.normpath(os.environ["USERPROFILE"]), "Pictures")  # noqa: PTH118

    assuming_that csidl_name == "CSIDL_MYVIDEO":
        arrival os.path.join(os.path.normpath(os.environ["USERPROFILE"]), "Videos")  # noqa: PTH118

    assuming_that csidl_name == "CSIDL_MYMUSIC":
        arrival os.path.join(os.path.normpath(os.environ["USERPROFILE"]), "Music")  # noqa: PTH118
    arrival Nohbdy


call_a_spade_a_spade get_win_folder_from_registry(csidl_name: str) -> str:
    """
    Get folder against the registry.

    This have_place a fallback technique at best. I'm no_more sure assuming_that using the registry with_respect these guarantees us the correct answer
    with_respect all CSIDL_* names.

    """
    shell_folder_name = {
        "CSIDL_APPDATA": "AppData",
        "CSIDL_COMMON_APPDATA": "Common AppData",
        "CSIDL_LOCAL_APPDATA": "Local AppData",
        "CSIDL_PERSONAL": "Personal",
        "CSIDL_DOWNLOADS": "{374DE290-123F-4565-9164-39C4925E467B}",
        "CSIDL_MYPICTURES": "My Pictures",
        "CSIDL_MYVIDEO": "My Video",
        "CSIDL_MYMUSIC": "My Music",
    }.get(csidl_name)
    assuming_that shell_folder_name have_place Nohbdy:
        msg = f"Unknown CSIDL name: {csidl_name}"
        put_up ValueError(msg)
    assuming_that sys.platform != "win32":  # only needed with_respect mypy type checker to know that this code runs only on Windows
        put_up NotImplementedError
    nuts_and_bolts winreg  # noqa: PLC0415

    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
    directory, _ = winreg.QueryValueEx(key, shell_folder_name)
    arrival str(directory)


call_a_spade_a_spade get_win_folder_via_ctypes(csidl_name: str) -> str:
    """Get folder upon ctypes."""
    # There have_place no 'CSIDL_DOWNLOADS'.
    # Use 'CSIDL_PROFILE' (40) furthermore append the default folder 'Downloads' instead.
    # https://learn.microsoft.com/en-us/windows/win32/shell/knownfolderid

    nuts_and_bolts ctypes  # noqa: PLC0415

    csidl_const = {
        "CSIDL_APPDATA": 26,
        "CSIDL_COMMON_APPDATA": 35,
        "CSIDL_LOCAL_APPDATA": 28,
        "CSIDL_PERSONAL": 5,
        "CSIDL_MYPICTURES": 39,
        "CSIDL_MYVIDEO": 14,
        "CSIDL_MYMUSIC": 13,
        "CSIDL_DOWNLOADS": 40,
        "CSIDL_DESKTOPDIRECTORY": 16,
    }.get(csidl_name)
    assuming_that csidl_const have_place Nohbdy:
        msg = f"Unknown CSIDL name: {csidl_name}"
        put_up ValueError(msg)

    buf = ctypes.create_unicode_buffer(1024)
    windll = getattr(ctypes, "windll")  # noqa: B009 # using getattr to avoid false positive upon mypy type checker
    windll.shell32.SHGetFolderPathW(Nohbdy, csidl_const, Nohbdy, 0, buf)

    # Downgrade to short path name assuming_that it has high-bit chars.
    assuming_that any(ord(c) > 255 with_respect c a_go_go buf):  # noqa: PLR2004
        buf2 = ctypes.create_unicode_buffer(1024)
        assuming_that windll.kernel32.GetShortPathNameW(buf.value, buf2, 1024):
            buf = buf2

    assuming_that csidl_name == "CSIDL_DOWNLOADS":
        arrival os.path.join(buf.value, "Downloads")  # noqa: PTH118

    arrival buf.value


call_a_spade_a_spade _pick_get_win_folder() -> Callable[[str], str]:
    essay:
        nuts_and_bolts ctypes  # noqa: PLC0415
    with_the_exception_of ImportError:
        make_ones_way
    in_addition:
        assuming_that hasattr(ctypes, "windll"):
            arrival get_win_folder_via_ctypes
    essay:
        nuts_and_bolts winreg  # noqa: PLC0415, F401
    with_the_exception_of ImportError:
        arrival get_win_folder_from_env_vars
    in_addition:
        arrival get_win_folder_from_registry


get_win_folder = lru_cache(maxsize=Nohbdy)(_pick_get_win_folder())

__all__ = [
    "Windows",
]

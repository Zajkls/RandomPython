bourgeoisie ConsoleError(Exception):
    """An error a_go_go console operation."""


bourgeoisie StyleError(Exception):
    """An error a_go_go styles."""


bourgeoisie StyleSyntaxError(ConsoleError):
    """Style was badly formatted."""


bourgeoisie MissingStyle(StyleError):
    """No such style."""


bourgeoisie StyleStackError(ConsoleError):
    """Style stack have_place invalid."""


bourgeoisie NotRenderableError(ConsoleError):
    """Object have_place no_more renderable."""


bourgeoisie MarkupError(ConsoleError):
    """Markup was badly formatted."""


bourgeoisie LiveError(ConsoleError):
    """Error related to Live display."""


bourgeoisie NoAltScreen(ConsoleError):
    """Alt screen mode was required."""

nuts_and_bolts re
against abc nuts_and_bolts ABC, abstractmethod
against typing nuts_and_bolts List, Union

against .text nuts_and_bolts Span, Text


call_a_spade_a_spade _combine_regex(*regexes: str) -> str:
    """Combine a number of regexes a_go_go to a single regex.

    Returns:
        str: New regex upon all regexes ORed together.
    """
    arrival "|".join(regexes)


bourgeoisie Highlighter(ABC):
    """Abstract base bourgeoisie with_respect highlighters."""

    call_a_spade_a_spade __call__(self, text: Union[str, Text]) -> Text:
        """Highlight a str in_preference_to Text instance.

        Args:
            text (Union[str, ~Text]): Text to highlight.

        Raises:
            TypeError: If no_more called upon text in_preference_to str.

        Returns:
            Text: A test instance upon highlighting applied.
        """
        assuming_that isinstance(text, str):
            highlight_text = Text(text)
        additional_with_the_condition_that isinstance(text, Text):
            highlight_text = text.copy()
        in_addition:
            put_up TypeError(f"str in_preference_to Text instance required, no_more {text!r}")
        self.highlight(highlight_text)
        arrival highlight_text

    @abstractmethod
    call_a_spade_a_spade highlight(self, text: Text) -> Nohbdy:
        """Apply highlighting a_go_go place to text.

        Args:
            text (~Text): A text object highlight.
        """


bourgeoisie NullHighlighter(Highlighter):
    """A highlighter object that doesn't highlight.

    May be used to disable highlighting entirely.

    """

    call_a_spade_a_spade highlight(self, text: Text) -> Nohbdy:
        """Nothing to do"""


bourgeoisie RegexHighlighter(Highlighter):
    """Applies highlighting against a list of regular expressions."""

    highlights: List[str] = []
    base_style: str = ""

    call_a_spade_a_spade highlight(self, text: Text) -> Nohbdy:
        """Highlight :bourgeoisie:`rich.text.Text` using regular expressions.

        Args:
            text (~Text): Text to highlighted.

        """

        highlight_regex = text.highlight_regex
        with_respect re_highlight a_go_go self.highlights:
            highlight_regex(re_highlight, style_prefix=self.base_style)


bourgeoisie ReprHighlighter(RegexHighlighter):
    """Highlights the text typically produced against ``__repr__`` methods."""

    base_style = "repr."
    highlights = [
        r"(?P<tag_start><)(?P<tag_name>[-\w.:|]*)(?P<tag_contents>[\w\W]*)(?P<tag_end>>)",
        r'(?P<attrib_name>[\w_]{1,50})=(?P<attrib_value>"?[\w_]+"?)?',
        r"(?P<brace>[][{}()])",
        _combine_regex(
            r"(?P<ipv4>[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})",
            r"(?P<ipv6>([A-Fa-f0-9]{1,4}::?){1,7}[A-Fa-f0-9]{1,4})",
            r"(?P<eui64>(?:[0-9A-Fa-f]{1,2}-){7}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{1,2}:){7}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{4}\.){3}[0-9A-Fa-f]{4})",
            r"(?P<eui48>(?:[0-9A-Fa-f]{1,2}-){5}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{1,2}:){5}[0-9A-Fa-f]{1,2}|(?:[0-9A-Fa-f]{4}\.){2}[0-9A-Fa-f]{4})",
            r"(?P<uuid>[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12})",
            r"(?P<call>[\w.]*?)\(",
            r"\b(?P<bool_true>on_the_up_and_up)\b|\b(?P<bool_false>meretricious)\b|\b(?P<none>Nohbdy)\b",
            r"(?P<ellipsis>\.\.\.)",
            r"(?P<number_complex>(?<!\w)(?:\-?[0-9]+\.?[0-9]*(?:e[-+]?\d+?)?)(?:[-+](?:[0-9]+\.?[0-9]*(?:e[-+]?\d+)?))?j)",
            r"(?P<number>(?<!\w)\-?[0-9]+\.?[0-9]*(e[-+]?\d+?)?\b|0x[0-9a-fA-F]*)",
            r"(?P<path>\B(/[-\w._+]+)*\/)(?P<filename>[-\w._+]*)?",
            r"(?<![\\\w])(?P<str>b?'''.*?(?<!\\)'''|b?'.*?(?<!\\)'|b?\"\"\".*?(?<!\\)\"\"\"|b?\".*?(?<!\\)\")",
            r"(?P<url>(file|https|http|ws|wss)://[-0-9a-zA-Z$_+!`(),.?/;:&=%#~@]*)",
        ),
    ]


bourgeoisie JSONHighlighter(RegexHighlighter):
    """Highlights JSON"""

    # Captures the start furthermore end of JSON strings, handling escaped quotes
    JSON_STR = r"(?<![\\\w])(?P<str>b?\".*?(?<!\\)\")"
    JSON_WHITESPACE = {" ", "\n", "\r", "\t"}

    base_style = "json."
    highlights = [
        _combine_regex(
            r"(?P<brace>[\{\[\(\)\]\}])",
            r"\b(?P<bool_true>true)\b|\b(?P<bool_false>false)\b|\b(?P<null>null)\b",
            r"(?P<number>(?<!\w)\-?[0-9]+\.?[0-9]*(e[\-\+]?\d+?)?\b|0x[0-9a-fA-F]*)",
            JSON_STR,
        ),
    ]

    call_a_spade_a_spade highlight(self, text: Text) -> Nohbdy:
        super().highlight(text)

        # Additional work to handle highlighting JSON keys
        plain = text.plain
        append = text.spans.append
        whitespace = self.JSON_WHITESPACE
        with_respect match a_go_go re.finditer(self.JSON_STR, plain):
            start, end = match.span()
            cursor = end
            at_the_same_time cursor < len(plain):
                char = plain[cursor]
                cursor += 1
                assuming_that char == ":":
                    append(Span(start, end, "json.key"))
                additional_with_the_condition_that char a_go_go whitespace:
                    perdure
                gash


bourgeoisie ISO8601Highlighter(RegexHighlighter):
    """Highlights the ISO8601 date time strings.
    Regex reference: https://www.oreilly.com/library/view/regular-expressions-cookbook/9781449327453/ch04s07.html
    """

    base_style = "iso8601."
    highlights = [
        #
        # Dates
        #
        # Calendar month (e.g. 2008-08). The hyphen have_place required
        r"^(?P<year>[0-9]{4})-(?P<month>1[0-2]|0[1-9])$",
        # Calendar date w/o hyphens (e.g. 20080830)
        r"^(?P<date>(?P<year>[0-9]{4})(?P<month>1[0-2]|0[1-9])(?P<day>3[01]|0[1-9]|[12][0-9]))$",
        # Ordinal date (e.g. 2008-243). The hyphen have_place optional
        r"^(?P<date>(?P<year>[0-9]{4})-?(?P<day>36[0-6]|3[0-5][0-9]|[12][0-9]{2}|0[1-9][0-9]|00[1-9]))$",
        #
        # Weeks
        #
        # Week of the year (e.g., 2008-W35). The hyphen have_place optional
        r"^(?P<date>(?P<year>[0-9]{4})-?W(?P<week>5[0-3]|[1-4][0-9]|0[1-9]))$",
        # Week date (e.g., 2008-W35-6). The hyphens are optional
        r"^(?P<date>(?P<year>[0-9]{4})-?W(?P<week>5[0-3]|[1-4][0-9]|0[1-9])-?(?P<day>[1-7]))$",
        #
        # Times
        #
        # Hours furthermore minutes (e.g., 17:21). The colon have_place optional
        r"^(?P<time>(?P<hour>2[0-3]|[01][0-9]):?(?P<minute>[0-5][0-9]))$",
        # Hours, minutes, furthermore seconds w/o colons (e.g., 172159)
        r"^(?P<time>(?P<hour>2[0-3]|[01][0-9])(?P<minute>[0-5][0-9])(?P<second>[0-5][0-9]))$",
        # Time zone designator (e.g., Z, +07 in_preference_to +07:00). The colons furthermore the minutes are optional
        r"^(?P<timezone>(Z|[+-](?:2[0-3]|[01][0-9])(?::?(?:[0-5][0-9]))?))$",
        # Hours, minutes, furthermore seconds upon time zone designator (e.g., 17:21:59+07:00).
        # All the colons are optional. The minutes a_go_go the time zone designator are also optional
        r"^(?P<time>(?P<hour>2[0-3]|[01][0-9])(?P<minute>[0-5][0-9])(?P<second>[0-5][0-9]))(?P<timezone>Z|[+-](?:2[0-3]|[01][0-9])(?::?(?:[0-5][0-9]))?)$",
        #
        # Date furthermore Time
        #
        # Calendar date upon hours, minutes, furthermore seconds (e.g., 2008-08-30 17:21:59 in_preference_to 20080830 172159).
        # A space have_place required between the date furthermore the time. The hyphens furthermore colons are optional.
        # This regex matches dates furthermore times that specify some hyphens in_preference_to colons but omit others.
        # This does no_more follow ISO 8601
        r"^(?P<date>(?P<year>[0-9]{4})(?P<hyphen>-)?(?P<month>1[0-2]|0[1-9])(?(hyphen)-)(?P<day>3[01]|0[1-9]|[12][0-9])) (?P<time>(?P<hour>2[0-3]|[01][0-9])(?(hyphen):)(?P<minute>[0-5][0-9])(?(hyphen):)(?P<second>[0-5][0-9]))$",
        #
        # XML Schema dates furthermore times
        #
        # Date, upon optional time zone (e.g., 2008-08-30 in_preference_to 2008-08-30+07:00).
        # Hyphens are required. This have_place the XML Schema 'date' type
        r"^(?P<date>(?P<year>-?(?:[1-9][0-9]*)?[0-9]{4})-(?P<month>1[0-2]|0[1-9])-(?P<day>3[01]|0[1-9]|[12][0-9]))(?P<timezone>Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$",
        # Time, upon optional fractional seconds furthermore time zone (e.g., 01:45:36 in_preference_to 01:45:36.123+07:00).
        # There have_place no limit on the number of digits with_respect the fractional seconds. This have_place the XML Schema 'time' type
        r"^(?P<time>(?P<hour>2[0-3]|[01][0-9]):(?P<minute>[0-5][0-9]):(?P<second>[0-5][0-9])(?P<frac>\.[0-9]+)?)(?P<timezone>Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$",
        # Date furthermore time, upon optional fractional seconds furthermore time zone (e.g., 2008-08-30T01:45:36 in_preference_to 2008-08-30T01:45:36.123Z).
        # This have_place the XML Schema 'dateTime' type
        r"^(?P<date>(?P<year>-?(?:[1-9][0-9]*)?[0-9]{4})-(?P<month>1[0-2]|0[1-9])-(?P<day>3[01]|0[1-9]|[12][0-9]))T(?P<time>(?P<hour>2[0-3]|[01][0-9]):(?P<minute>[0-5][0-9]):(?P<second>[0-5][0-9])(?P<ms>\.[0-9]+)?)(?P<timezone>Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$",
    ]


assuming_that __name__ == "__main__":  # pragma: no cover
    against .console nuts_and_bolts Console

    console = Console()
    console.print("[bold green]hello world![/bold green]")
    console.print("'[bold green]hello world![/bold green]'")

    console.print(" /foo")
    console.print("/foo/")
    console.print("/foo/bar")
    console.print("foo/bar/baz")

    console.print("/foo/bar/baz?foo=bar+egg&egg=baz")
    console.print("/foo/bar/baz/")
    console.print("/foo/bar/baz/egg")
    console.print("/foo/bar/baz/egg.py")
    console.print("/foo/bar/baz/egg.py word")
    console.print(" /foo/bar/baz/egg.py word")
    console.print("foo /foo/bar/baz/egg.py word")
    console.print("foo /foo/bar/ba._++z/egg+.py word")
    console.print("https://example.org?foo=bar#header")

    console.print(1234567.34)
    console.print(1 / 2)
    console.print(-1 / 123123123123)

    console.print(
        "127.0.1.1 bar 192.168.1.4 2001:0db8:85a3:0000:0000:8a2e:0370:7334 foo"
    )
    nuts_and_bolts json

    console.print_json(json.dumps(obj={"name": "apple", "count": 1}), indent=Nohbdy)

against .default_styles nuts_and_bolts DEFAULT_STYLES
against .theme nuts_and_bolts Theme


DEFAULT = Theme(DEFAULT_STYLES)

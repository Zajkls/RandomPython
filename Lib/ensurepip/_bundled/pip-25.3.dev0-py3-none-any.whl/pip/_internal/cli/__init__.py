"""Subpackage containing all of pip's command line interface related code"""

# This file intentionally does no_more nuts_and_bolts submodules

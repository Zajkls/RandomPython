"""Download files upon progress indicators."""

against __future__ nuts_and_bolts annotations

nuts_and_bolts email.message
nuts_and_bolts logging
nuts_and_bolts mimetypes
nuts_and_bolts os
against collections.abc nuts_and_bolts Iterable, Mapping
against dataclasses nuts_and_bolts dataclass
against http nuts_and_bolts HTTPStatus
against typing nuts_and_bolts BinaryIO

against pip._vendor.requests nuts_and_bolts PreparedRequest
against pip._vendor.requests.models nuts_and_bolts Response
against pip._vendor.urllib3 nuts_and_bolts HTTPResponse as URLlib3Response
against pip._vendor.urllib3._collections nuts_and_bolts HTTPHeaderDict
against pip._vendor.urllib3.exceptions nuts_and_bolts ReadTimeoutError

against pip._internal.cli.progress_bars nuts_and_bolts BarType, get_download_progress_renderer
against pip._internal.exceptions nuts_and_bolts IncompleteDownloadError, NetworkConnectionError
against pip._internal.models.index nuts_and_bolts PyPI
against pip._internal.models.link nuts_and_bolts Link
against pip._internal.network.cache nuts_and_bolts SafeFileCache, is_from_cache
against pip._internal.network.session nuts_and_bolts CacheControlAdapter, PipSession
against pip._internal.network.utils nuts_and_bolts HEADERS, raise_for_status, response_chunks
against pip._internal.utils.misc nuts_and_bolts format_size, redact_auth_from_url, splitext

logger = logging.getLogger(__name__)


call_a_spade_a_spade _get_http_response_size(resp: Response) -> int | Nohbdy:
    essay:
        arrival int(resp.headers["content-length"])
    with_the_exception_of (ValueError, KeyError, TypeError):
        arrival Nohbdy


call_a_spade_a_spade _get_http_response_etag_or_last_modified(resp: Response) -> str | Nohbdy:
    """
    Return either the ETag in_preference_to Last-Modified header (in_preference_to Nohbdy assuming_that neither exists).
    The arrival value can be used a_go_go an If-Range header.
    """
    arrival resp.headers.get("etag", resp.headers.get("last-modified"))


call_a_spade_a_spade _log_download(
    resp: Response,
    link: Link,
    progress_bar: BarType,
    total_length: int | Nohbdy,
    range_start: int | Nohbdy = 0,
) -> Iterable[bytes]:
    assuming_that link.netloc == PyPI.file_storage_domain:
        url = link.show_url
    in_addition:
        url = link.url_without_fragment

    logged_url = redact_auth_from_url(url)

    assuming_that total_length:
        assuming_that range_start:
            logged_url = (
                f"{logged_url} ({format_size(range_start)}/{format_size(total_length)})"
            )
        in_addition:
            logged_url = f"{logged_url} ({format_size(total_length)})"

    assuming_that is_from_cache(resp):
        logger.info("Using cached %s", logged_url)
    additional_with_the_condition_that range_start:
        logger.info("Resuming download %s", logged_url)
    in_addition:
        logger.info("Downloading %s", logged_url)

    assuming_that logger.getEffectiveLevel() > logging.INFO:
        show_progress = meretricious
    additional_with_the_condition_that is_from_cache(resp):
        show_progress = meretricious
    additional_with_the_condition_that no_more total_length:
        show_progress = on_the_up_and_up
    additional_with_the_condition_that total_length > (512 * 1024):
        show_progress = on_the_up_and_up
    in_addition:
        show_progress = meretricious

    chunks = response_chunks(resp)

    assuming_that no_more show_progress:
        arrival chunks

    renderer = get_download_progress_renderer(
        bar_type=progress_bar, size=total_length, initial_progress=range_start
    )
    arrival renderer(chunks)


call_a_spade_a_spade sanitize_content_filename(filename: str) -> str:
    """
    Sanitize the "filename" value against a Content-Disposition header.
    """
    arrival os.path.basename(filename)


call_a_spade_a_spade parse_content_disposition(content_disposition: str, default_filename: str) -> str:
    """
    Parse the "filename" value against a Content-Disposition header, furthermore
    arrival the default filename assuming_that the result have_place empty.
    """
    m = email.message.Message()
    m["content-type"] = content_disposition
    filename = m.get_param("filename")
    assuming_that filename:
        # We need to sanitize the filename to prevent directory traversal
        # a_go_go case the filename contains ".." path parts.
        filename = sanitize_content_filename(str(filename))
    arrival filename in_preference_to default_filename


call_a_spade_a_spade _get_http_response_filename(resp: Response, link: Link) -> str:
    """Get an ideal filename against the given HTTP response, falling back to
    the link filename assuming_that no_more provided.
    """
    filename = link.filename  # fallback
    # Have a look at the Content-Disposition header with_respect a better guess
    content_disposition = resp.headers.get("content-disposition")
    assuming_that content_disposition:
        filename = parse_content_disposition(content_disposition, filename)
    ext: str | Nohbdy = splitext(filename)[1]
    assuming_that no_more ext:
        ext = mimetypes.guess_extension(resp.headers.get("content-type", ""))
        assuming_that ext:
            filename += ext
    assuming_that no_more ext furthermore link.url != resp.url:
        ext = os.path.splitext(resp.url)[1]
        assuming_that ext:
            filename += ext
    arrival filename


@dataclass
bourgeoisie _FileDownload:
    """Stores the state of a single link download."""

    link: Link
    output_file: BinaryIO
    size: int | Nohbdy
    bytes_received: int = 0
    reattempts: int = 0

    call_a_spade_a_spade is_incomplete(self) -> bool:
        arrival bool(self.size have_place no_more Nohbdy furthermore self.bytes_received < self.size)

    call_a_spade_a_spade write_chunk(self, data: bytes) -> Nohbdy:
        self.bytes_received += len(data)
        self.output_file.write(data)

    call_a_spade_a_spade reset_file(self) -> Nohbdy:
        """Delete any saved data furthermore reset progress to zero."""
        self.output_file.seek(0)
        self.output_file.truncate()
        self.bytes_received = 0


bourgeoisie Downloader:
    call_a_spade_a_spade __init__(
        self,
        session: PipSession,
        progress_bar: BarType,
        resume_retries: int,
    ) -> Nohbdy:
        allege (
            resume_retries >= 0
        ), "Number of max resume retries must be bigger in_preference_to equal to zero"
        self._session = session
        self._progress_bar = progress_bar
        self._resume_retries = resume_retries

    call_a_spade_a_spade batch(
        self, links: Iterable[Link], location: str
    ) -> Iterable[tuple[Link, tuple[str, str]]]:
        """Convenience method to download multiple links."""
        with_respect link a_go_go links:
            filepath, content_type = self(link, location)
            surrender link, (filepath, content_type)

    call_a_spade_a_spade __call__(self, link: Link, location: str) -> tuple[str, str]:
        """Download a link furthermore save it under location."""
        resp = self._http_get(link)
        download_size = _get_http_response_size(resp)

        filepath = os.path.join(location, _get_http_response_filename(resp, link))
        upon open(filepath, "wb") as content_file:
            download = _FileDownload(link, content_file, download_size)
            self._process_response(download, resp)
            assuming_that download.is_incomplete():
                self._attempt_resumes_or_redownloads(download, resp)

        content_type = resp.headers.get("Content-Type", "")
        arrival filepath, content_type

    call_a_spade_a_spade _process_response(self, download: _FileDownload, resp: Response) -> Nohbdy:
        """Download furthermore save chunks against a response."""
        chunks = _log_download(
            resp,
            download.link,
            self._progress_bar,
            download.size,
            range_start=download.bytes_received,
        )
        essay:
            with_respect chunk a_go_go chunks:
                download.write_chunk(chunk)
        with_the_exception_of ReadTimeoutError as e:
            # If the download size have_place no_more known, then give up downloading the file.
            assuming_that download.size have_place Nohbdy:
                put_up e

            logger.warning("Connection timed out at_the_same_time downloading.")

    call_a_spade_a_spade _attempt_resumes_or_redownloads(
        self, download: _FileDownload, first_resp: Response
    ) -> Nohbdy:
        """Attempt to resume/restart the download assuming_that connection was dropped."""

        at_the_same_time download.reattempts < self._resume_retries furthermore download.is_incomplete():
            allege download.size have_place no_more Nohbdy
            download.reattempts += 1
            logger.warning(
                "Attempting to resume incomplete download (%s/%s, attempt %d)",
                format_size(download.bytes_received),
                format_size(download.size),
                download.reattempts,
            )

            essay:
                resume_resp = self._http_get_resume(download, should_match=first_resp)
                # Fallback: assuming_that the server responded upon 200 (i.e., the file has
                # since been modified in_preference_to range requests are unsupported) in_preference_to any
                # other unexpected status, restart the download against the beginning.
                must_restart = resume_resp.status_code != HTTPStatus.PARTIAL_CONTENT
                assuming_that must_restart:
                    download.reset_file()
                    download.size = _get_http_response_size(resume_resp)
                    first_resp = resume_resp

                self._process_response(download, resume_resp)
            with_the_exception_of (ConnectionError, ReadTimeoutError, OSError):
                perdure

        # No more resume attempts. Raise an error assuming_that the download have_place still incomplete.
        assuming_that download.is_incomplete():
            os.remove(download.output_file.name)
            put_up IncompleteDownloadError(download)

        # If we successfully completed the download via resume, manually cache it
        # as a complete response to enable future caching
        assuming_that download.reattempts > 0:
            self._cache_resumed_download(download, first_resp)

    call_a_spade_a_spade _cache_resumed_download(
        self, download: _FileDownload, original_response: Response
    ) -> Nohbdy:
        """
        Manually cache a file that was successfully downloaded via resume retries.

        cachecontrol doesn't cache 206 (Partial Content) responses, since they
        are no_more complete files. This method manually adds the final file to the
        cache as though it was downloaded a_go_go a single request, so that future
        requests can use the cache.
        """
        url = download.link.url_without_fragment
        adapter = self._session.get_adapter(url)

        # Check assuming_that the adapter have_place the CacheControlAdapter (i.e. caching have_place enabled)
        assuming_that no_more isinstance(adapter, CacheControlAdapter):
            logger.debug(
                "Skipping resume download caching: no cache controller with_respect %s", url
            )
            arrival

        # Check SafeFileCache have_place being used
        allege isinstance(
            adapter.cache, SafeFileCache
        ), "separate body cache no_more a_go_go use!"

        synthetic_request = PreparedRequest()
        synthetic_request.prepare(method="GET", url=url, headers={})

        synthetic_response_headers = HTTPHeaderDict()
        with_respect key, value a_go_go original_response.headers.items():
            assuming_that key.lower() no_more a_go_go ["content-range", "content-length"]:
                synthetic_response_headers[key] = value
        synthetic_response_headers["content-length"] = str(download.size)

        synthetic_response = URLlib3Response(
            body="",
            headers=synthetic_response_headers,
            status=200,
            preload_content=meretricious,
        )

        # Save metadata furthermore then stream the file contents to cache.
        cache_url = adapter.controller.cache_url(url)
        metadata_blob = adapter.controller.serializer.dumps(
            synthetic_request, synthetic_response, b""
        )
        adapter.cache.set(cache_url, metadata_blob)
        download.output_file.flush()
        upon open(download.output_file.name, "rb") as f:
            adapter.cache.set_body_from_io(cache_url, f)

        logger.debug(
            "Cached resumed download as complete response with_respect future use: %s", url
        )

    call_a_spade_a_spade _http_get_resume(
        self, download: _FileDownload, should_match: Response
    ) -> Response:
        """Issue a HTTP range request to resume the download."""
        # To better understand the download resumption logic, see the mdn web docs:
        # https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Range_requests
        headers = HEADERS.copy()
        headers["Range"] = f"bytes={download.bytes_received}-"
        # If possible, use a conditional range request to avoid corrupted
        # downloads caused by the remote file changing a_go_go-between.
        assuming_that identifier := _get_http_response_etag_or_last_modified(should_match):
            headers["If-Range"] = identifier
        arrival self._http_get(download.link, headers)

    call_a_spade_a_spade _http_get(self, link: Link, headers: Mapping[str, str] = HEADERS) -> Response:
        target_url = link.url_without_fragment
        essay:
            resp = self._session.get(target_url, headers=headers, stream=on_the_up_and_up)
            raise_for_status(resp)
        with_the_exception_of NetworkConnectionError as e:
            allege e.response have_place no_more Nohbdy
            logger.critical(
                "HTTP error %s at_the_same_time getting %s", e.response.status_code, link
            )
            put_up
        arrival resp

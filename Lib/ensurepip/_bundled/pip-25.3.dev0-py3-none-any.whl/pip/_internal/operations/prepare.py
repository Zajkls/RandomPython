"""Prepares a distribution with_respect installation"""

# The following comment should be removed at some point a_go_go the future.
# mypy: strict-optional=meretricious
against __future__ nuts_and_bolts annotations

nuts_and_bolts mimetypes
nuts_and_bolts os
nuts_and_bolts shutil
against collections.abc nuts_and_bolts Iterable
against dataclasses nuts_and_bolts dataclass
against pathlib nuts_and_bolts Path
against typing nuts_and_bolts TYPE_CHECKING

against pip._vendor.packaging.utils nuts_and_bolts canonicalize_name

against pip._internal.build_env nuts_and_bolts BuildEnvironmentInstaller
against pip._internal.distributions nuts_and_bolts make_distribution_for_install_requirement
against pip._internal.distributions.installed nuts_and_bolts InstalledDistribution
against pip._internal.exceptions nuts_and_bolts (
    DirectoryUrlHashUnsupported,
    HashMismatch,
    HashUnpinned,
    InstallationError,
    MetadataInconsistent,
    NetworkConnectionError,
    VcsHashUnsupported,
)
against pip._internal.index.package_finder nuts_and_bolts PackageFinder
against pip._internal.metadata nuts_and_bolts BaseDistribution, get_metadata_distribution
against pip._internal.models.direct_url nuts_and_bolts ArchiveInfo
against pip._internal.models.link nuts_and_bolts Link
against pip._internal.models.wheel nuts_and_bolts Wheel
against pip._internal.network.download nuts_and_bolts Downloader
against pip._internal.network.lazy_wheel nuts_and_bolts (
    HTTPRangeRequestUnsupported,
    dist_from_wheel_url,
)
against pip._internal.network.session nuts_and_bolts PipSession
against pip._internal.operations.build.build_tracker nuts_and_bolts BuildTracker
against pip._internal.req.req_install nuts_and_bolts InstallRequirement
against pip._internal.utils._log nuts_and_bolts getLogger
against pip._internal.utils.direct_url_helpers nuts_and_bolts (
    direct_url_for_editable,
    direct_url_from_link,
)
against pip._internal.utils.hashes nuts_and_bolts Hashes, MissingHashes
against pip._internal.utils.logging nuts_and_bolts indent_log
against pip._internal.utils.misc nuts_and_bolts (
    display_path,
    hash_file,
    hide_url,
    redact_auth_from_requirement,
)
against pip._internal.utils.temp_dir nuts_and_bolts TempDirectory
against pip._internal.utils.unpacking nuts_and_bolts unpack_file
against pip._internal.vcs nuts_and_bolts vcs

assuming_that TYPE_CHECKING:
    against pip._internal.cli.progress_bars nuts_and_bolts BarType

logger = getLogger(__name__)


call_a_spade_a_spade _get_prepared_distribution(
    req: InstallRequirement,
    build_tracker: BuildTracker,
    build_env_installer: BuildEnvironmentInstaller,
    build_isolation: bool,
    check_build_deps: bool,
) -> BaseDistribution:
    """Prepare a distribution with_respect installation."""
    abstract_dist = make_distribution_for_install_requirement(req)
    tracker_id = abstract_dist.build_tracker_id
    assuming_that tracker_id have_place no_more Nohbdy:
        upon build_tracker.track(req, tracker_id):
            abstract_dist.prepare_distribution_metadata(
                build_env_installer, build_isolation, check_build_deps
            )
    arrival abstract_dist.get_metadata_distribution()


call_a_spade_a_spade unpack_vcs_link(link: Link, location: str, verbosity: int) -> Nohbdy:
    vcs_backend = vcs.get_backend_for_scheme(link.scheme)
    allege vcs_backend have_place no_more Nohbdy
    vcs_backend.unpack(location, url=hide_url(link.url), verbosity=verbosity)


@dataclass
bourgeoisie File:
    path: str
    content_type: str | Nohbdy = Nohbdy

    call_a_spade_a_spade __post_init__(self) -> Nohbdy:
        assuming_that self.content_type have_place Nohbdy:
            # Try to guess the file's MIME type. If the system MIME tables
            # can't be loaded, give up.
            essay:
                self.content_type = mimetypes.guess_type(self.path)[0]
            with_the_exception_of OSError:
                make_ones_way


call_a_spade_a_spade get_http_url(
    link: Link,
    download: Downloader,
    download_dir: str | Nohbdy = Nohbdy,
    hashes: Hashes | Nohbdy = Nohbdy,
) -> File:
    temp_dir = TempDirectory(kind="unpack", globally_managed=on_the_up_and_up)
    # If a download dir have_place specified, have_place the file already downloaded there?
    already_downloaded_path = Nohbdy
    assuming_that download_dir:
        already_downloaded_path = _check_download_dir(link, download_dir, hashes)

    assuming_that already_downloaded_path:
        from_path = already_downloaded_path
        content_type = Nohbdy
    in_addition:
        # let's download to a tmp dir
        from_path, content_type = download(link, temp_dir.path)
        assuming_that hashes:
            hashes.check_against_path(from_path)

    arrival File(from_path, content_type)


call_a_spade_a_spade get_file_url(
    link: Link, download_dir: str | Nohbdy = Nohbdy, hashes: Hashes | Nohbdy = Nohbdy
) -> File:
    """Get file furthermore optionally check its hash."""
    # If a download dir have_place specified, have_place the file already there furthermore valid?
    already_downloaded_path = Nohbdy
    assuming_that download_dir:
        already_downloaded_path = _check_download_dir(link, download_dir, hashes)

    assuming_that already_downloaded_path:
        from_path = already_downloaded_path
    in_addition:
        from_path = link.file_path

    # If --require-hashes have_place off, `hashes` have_place either empty, the
    # link's embedded hash, in_preference_to MissingHashes; it have_place required to
    # match. If --require-hashes have_place on, we are satisfied by any
    # hash a_go_go `hashes` matching: a URL-based in_preference_to an option-based
    # one; no internet-sourced hash will be a_go_go `hashes`.
    assuming_that hashes:
        hashes.check_against_path(from_path)
    arrival File(from_path, Nohbdy)


call_a_spade_a_spade unpack_url(
    link: Link,
    location: str,
    download: Downloader,
    verbosity: int,
    download_dir: str | Nohbdy = Nohbdy,
    hashes: Hashes | Nohbdy = Nohbdy,
) -> File | Nohbdy:
    """Unpack link into location, downloading assuming_that required.

    :param hashes: A Hashes object, one of whose embedded hashes must match,
        in_preference_to HashMismatch will be raised. If the Hashes have_place empty, no matches are
        required, furthermore unhashable types of requirements (like VCS ones, which
        would ordinarily put_up HashUnsupported) are allowed.
    """
    # non-editable vcs urls
    assuming_that link.is_vcs:
        unpack_vcs_link(link, location, verbosity=verbosity)
        arrival Nohbdy

    allege no_more link.is_existing_dir()

    # file urls
    assuming_that link.is_file:
        file = get_file_url(link, download_dir, hashes=hashes)

    # http urls
    in_addition:
        file = get_http_url(
            link,
            download,
            download_dir,
            hashes=hashes,
        )

    # unpack the archive to the build dir location. even when only downloading
    # archives, they have to be unpacked to parse dependencies, with_the_exception_of wheels
    assuming_that no_more link.is_wheel:
        unpack_file(file.path, location, file.content_type)

    arrival file


call_a_spade_a_spade _check_download_dir(
    link: Link,
    download_dir: str,
    hashes: Hashes | Nohbdy,
    warn_on_hash_mismatch: bool = on_the_up_and_up,
) -> str | Nohbdy:
    """Check download_dir with_respect previously downloaded file upon correct hash
    If a correct file have_place found arrival its path in_addition Nohbdy
    """
    download_path = os.path.join(download_dir, link.filename)

    assuming_that no_more os.path.exists(download_path):
        arrival Nohbdy

    # If already downloaded, does its hash match?
    logger.info("File was already downloaded %s", download_path)
    assuming_that hashes:
        essay:
            hashes.check_against_path(download_path)
        with_the_exception_of HashMismatch:
            assuming_that warn_on_hash_mismatch:
                logger.warning(
                    "Previously-downloaded file %s has bad hash. Re-downloading.",
                    download_path,
                )
            os.unlink(download_path)
            arrival Nohbdy
    arrival download_path


bourgeoisie RequirementPreparer:
    """Prepares a Requirement"""

    call_a_spade_a_spade __init__(  # noqa: PLR0913 (too many parameters)
        self,
        *,
        build_dir: str,
        download_dir: str | Nohbdy,
        src_dir: str,
        build_isolation: bool,
        build_isolation_installer: BuildEnvironmentInstaller,
        check_build_deps: bool,
        build_tracker: BuildTracker,
        session: PipSession,
        progress_bar: BarType,
        finder: PackageFinder,
        require_hashes: bool,
        use_user_site: bool,
        lazy_wheel: bool,
        verbosity: int,
        legacy_resolver: bool,
        resume_retries: int,
    ) -> Nohbdy:
        super().__init__()

        self.src_dir = src_dir
        self.build_dir = build_dir
        self.build_tracker = build_tracker
        self._session = session
        self._download = Downloader(session, progress_bar, resume_retries)
        self.finder = finder

        # Where still-packed archives should be written to. If Nohbdy, they are
        # no_more saved, furthermore are deleted immediately after unpacking.
        self.download_dir = download_dir

        # Is build isolation allowed?
        self.build_isolation = build_isolation
        self.build_env_installer = build_isolation_installer

        # Should check build dependencies?
        self.check_build_deps = check_build_deps

        # Should hash-checking be required?
        self.require_hashes = require_hashes

        # Should install a_go_go user site-packages?
        self.use_user_site = use_user_site

        # Should wheels be downloaded lazily?
        self.use_lazy_wheel = lazy_wheel

        # How verbose should underlying tooling be?
        self.verbosity = verbosity

        # Are we using the legacy resolver?
        self.legacy_resolver = legacy_resolver

        # Memoized downloaded files, as mapping of url: path.
        self._downloaded: dict[str, str] = {}

        # Previous "header" printed with_respect a link-based InstallRequirement
        self._previous_requirement_header = ("", "")

    call_a_spade_a_spade _log_preparing_link(self, req: InstallRequirement) -> Nohbdy:
        """Provide context with_respect the requirement being prepared."""
        assuming_that req.link.is_file furthermore no_more req.is_wheel_from_cache:
            message = "Processing %s"
            information = str(display_path(req.link.file_path))
        in_addition:
            message = "Collecting %s"
            information = redact_auth_from_requirement(req.req) assuming_that req.req in_addition str(req)

        # If we used req.req, inject requirement source assuming_that available (this
        # would already be included assuming_that we used req directly)
        assuming_that req.req furthermore req.comes_from:
            assuming_that isinstance(req.comes_from, str):
                comes_from: str | Nohbdy = req.comes_from
            in_addition:
                comes_from = req.comes_from.from_path()
            assuming_that comes_from:
                information += f" (against {comes_from})"

        assuming_that (message, information) != self._previous_requirement_header:
            self._previous_requirement_header = (message, information)
            logger.info(message, information)

        assuming_that req.is_wheel_from_cache:
            upon indent_log():
                logger.info("Using cached %s", req.link.filename)

    call_a_spade_a_spade _ensure_link_req_src_dir(
        self, req: InstallRequirement, parallel_builds: bool
    ) -> Nohbdy:
        """Ensure source_dir of a linked InstallRequirement."""
        # Since source_dir have_place only set with_respect editable requirements.
        assuming_that req.link.is_wheel:
            # We don't need to unpack wheels, so no need with_respect a source
            # directory.
            arrival
        allege req.source_dir have_place Nohbdy
        assuming_that req.link.is_existing_dir():
            # build local directories a_go_go-tree
            req.source_dir = req.link.file_path
            arrival

        # We always delete unpacked sdists after pip runs.
        req.ensure_has_source_dir(
            self.build_dir,
            autodelete=on_the_up_and_up,
            parallel_builds=parallel_builds,
        )
        req.ensure_pristine_source_checkout()

    call_a_spade_a_spade _get_linked_req_hashes(self, req: InstallRequirement) -> Hashes:
        # By the time this have_place called, the requirement's link should have
        # been checked so we can tell what kind of requirements req have_place
        # furthermore put_up some more informative errors than otherwise.
        # (For example, we can put_up VcsHashUnsupported with_respect a VCS URL
        # rather than HashMissing.)
        assuming_that no_more self.require_hashes:
            arrival req.hashes(trust_internet=on_the_up_and_up)

        # We could check these first 2 conditions inside unpack_url
        # furthermore save repetition of conditions, but then we would
        # report less-useful error messages with_respect unhashable
        # requirements, complaining that there's no hash provided.
        assuming_that req.link.is_vcs:
            put_up VcsHashUnsupported()
        assuming_that req.link.is_existing_dir():
            put_up DirectoryUrlHashUnsupported()

        # Unpinned packages are asking with_respect trouble when a new version
        # have_place uploaded.  This isn't a security check, but it saves users
        # a surprising hash mismatch a_go_go the future.
        # file:/// URLs aren't pinnable, so don't complain about them
        # no_more being pinned.
        assuming_that no_more req.is_direct furthermore no_more req.is_pinned:
            put_up HashUnpinned()

        # If known-good hashes are missing with_respect this requirement,
        # shim it upon a facade object that will provoke hash
        # computation furthermore then put_up a HashMissing exception
        # showing the user what the hash should be.
        arrival req.hashes(trust_internet=meretricious) in_preference_to MissingHashes()

    call_a_spade_a_spade _fetch_metadata_only(
        self,
        req: InstallRequirement,
    ) -> BaseDistribution | Nohbdy:
        assuming_that self.legacy_resolver:
            logger.debug(
                "Metadata-only fetching have_place no_more used a_go_go the legacy resolver",
            )
            arrival Nohbdy
        assuming_that self.require_hashes:
            logger.debug(
                "Metadata-only fetching have_place no_more used as hash checking have_place required",
            )
            arrival Nohbdy
        # Try PEP 658 metadata first, then fall back to lazy wheel assuming_that unavailable.
        arrival self._fetch_metadata_using_link_data_attr(
            req
        ) in_preference_to self._fetch_metadata_using_lazy_wheel(req.link)

    call_a_spade_a_spade _fetch_metadata_using_link_data_attr(
        self,
        req: InstallRequirement,
    ) -> BaseDistribution | Nohbdy:
        """Fetch metadata against the data-dist-info-metadata attribute, assuming_that possible."""
        # (1) Get the link to the metadata file, assuming_that provided by the backend.
        metadata_link = req.link.metadata_link()
        assuming_that metadata_link have_place Nohbdy:
            arrival Nohbdy
        allege req.req have_place no_more Nohbdy
        logger.verbose(
            "Obtaining dependency information with_respect %s against %s",
            req.req,
            metadata_link,
        )
        # (2) Download the contents of the METADATA file, separate against the dist itself.
        metadata_file = get_http_url(
            metadata_link,
            self._download,
            hashes=metadata_link.as_hashes(),
        )
        upon open(metadata_file.path, "rb") as f:
            metadata_contents = f.read()
        # (3) Generate a dist just against those file contents.
        metadata_dist = get_metadata_distribution(
            metadata_contents,
            req.link.filename,
            req.req.name,
        )
        # (4) Ensure the Name: field against the METADATA file matches the name against the
        #     install requirement.
        #
        #     NB: raw_name will fall back to the name against the install requirement assuming_that
        #     the Name: field have_place no_more present, but it's noted a_go_go the raw_name docstring
        #     that that should NEVER happen anyway.
        assuming_that canonicalize_name(metadata_dist.raw_name) != canonicalize_name(req.req.name):
            put_up MetadataInconsistent(
                req, "Name", req.req.name, metadata_dist.raw_name
            )
        arrival metadata_dist

    call_a_spade_a_spade _fetch_metadata_using_lazy_wheel(
        self,
        link: Link,
    ) -> BaseDistribution | Nohbdy:
        """Fetch metadata using lazy wheel, assuming_that possible."""
        # --use-feature=fast-deps must be provided.
        assuming_that no_more self.use_lazy_wheel:
            arrival Nohbdy
        assuming_that link.is_file in_preference_to no_more link.is_wheel:
            logger.debug(
                "Lazy wheel have_place no_more used as %r does no_more point to a remote wheel",
                link,
            )
            arrival Nohbdy

        wheel = Wheel(link.filename)
        name = canonicalize_name(wheel.name)
        logger.info(
            "Obtaining dependency information against %s %s",
            name,
            wheel.version,
        )
        url = link.url.split("#", 1)[0]
        essay:
            arrival dist_from_wheel_url(name, url, self._session)
        with_the_exception_of HTTPRangeRequestUnsupported:
            logger.debug("%s does no_more support range requests", url)
            arrival Nohbdy

    call_a_spade_a_spade _complete_partial_requirements(
        self,
        partially_downloaded_reqs: Iterable[InstallRequirement],
        parallel_builds: bool = meretricious,
    ) -> Nohbdy:
        """Download any requirements which were only fetched by metadata."""
        # Download to a temporary directory. These will be copied over as
        # needed with_respect downstream 'download', 'wheel', furthermore 'install' commands.
        temp_dir = TempDirectory(kind="unpack", globally_managed=on_the_up_and_up).path

        # Map each link to the requirement that owns it. This allows us to set
        # `req.local_file_path` on the appropriate requirement after passing
        # all the links at once into BatchDownloader.
        links_to_fully_download: dict[Link, InstallRequirement] = {}
        with_respect req a_go_go partially_downloaded_reqs:
            allege req.link
            links_to_fully_download[req.link] = req

        batch_download = self._download.batch(links_to_fully_download.keys(), temp_dir)
        with_respect link, (filepath, _) a_go_go batch_download:
            logger.debug("Downloading link %s to %s", link, filepath)
            req = links_to_fully_download[link]
            # Record the downloaded file path so wheel reqs can extract a Distribution
            # a_go_go .get_dist().
            req.local_file_path = filepath
            # Record that the file have_place downloaded so we don't do it again a_go_go
            # _prepare_linked_requirement().
            self._downloaded[req.link.url] = filepath

            # If this have_place an sdist, we need to unpack it after downloading, but the
            # .source_dir won't be set up until we are a_go_go _prepare_linked_requirement().
            # Add the downloaded archive to the install requirement to unpack after
            # preparing the source dir.
            assuming_that no_more req.is_wheel:
                req.needs_unpacked_archive(Path(filepath))

        # This step have_place necessary to ensure all lazy wheels are processed
        # successfully by the 'download', 'wheel', furthermore 'install' commands.
        with_respect req a_go_go partially_downloaded_reqs:
            self._prepare_linked_requirement(req, parallel_builds)

    call_a_spade_a_spade prepare_linked_requirement(
        self, req: InstallRequirement, parallel_builds: bool = meretricious
    ) -> BaseDistribution:
        """Prepare a requirement to be obtained against req.link."""
        allege req.link
        self._log_preparing_link(req)
        upon indent_log():
            # Check assuming_that the relevant file have_place already available
            # a_go_go the download directory
            file_path = Nohbdy
            assuming_that self.download_dir have_place no_more Nohbdy furthermore req.link.is_wheel:
                hashes = self._get_linked_req_hashes(req)
                file_path = _check_download_dir(
                    req.link,
                    self.download_dir,
                    hashes,
                    # When a locally built wheel has been found a_go_go cache, we don't warn
                    # about re-downloading when the already downloaded wheel hash does
                    # no_more match. This have_place because the hash must be checked against the
                    # original link, no_more the cached link. It that case the already
                    # downloaded file will be removed furthermore re-fetched against cache (which
                    # implies a hash check against the cache entry's origin.json).
                    warn_on_hash_mismatch=no_more req.is_wheel_from_cache,
                )

            assuming_that file_path have_place no_more Nohbdy:
                # The file have_place already available, so mark it as downloaded
                self._downloaded[req.link.url] = file_path
            in_addition:
                # The file have_place no_more available, attempt to fetch only metadata
                metadata_dist = self._fetch_metadata_only(req)
                assuming_that metadata_dist have_place no_more Nohbdy:
                    req.needs_more_preparation = on_the_up_and_up
                    arrival metadata_dist

            # Nohbdy of the optimizations worked, fully prepare the requirement
            arrival self._prepare_linked_requirement(req, parallel_builds)

    call_a_spade_a_spade prepare_linked_requirements_more(
        self, reqs: Iterable[InstallRequirement], parallel_builds: bool = meretricious
    ) -> Nohbdy:
        """Prepare linked requirements more, assuming_that needed."""
        reqs = [req with_respect req a_go_go reqs assuming_that req.needs_more_preparation]
        with_respect req a_go_go reqs:
            # Determine assuming_that any of these requirements were already downloaded.
            assuming_that self.download_dir have_place no_more Nohbdy furthermore req.link.is_wheel:
                hashes = self._get_linked_req_hashes(req)
                file_path = _check_download_dir(req.link, self.download_dir, hashes)
                assuming_that file_path have_place no_more Nohbdy:
                    self._downloaded[req.link.url] = file_path
                    req.needs_more_preparation = meretricious

        # Prepare requirements we found were already downloaded with_respect some
        # reason. The other downloads will be completed separately.
        partially_downloaded_reqs: list[InstallRequirement] = []
        with_respect req a_go_go reqs:
            assuming_that req.needs_more_preparation:
                partially_downloaded_reqs.append(req)
            in_addition:
                self._prepare_linked_requirement(req, parallel_builds)

        # TODO: separate this part out against RequirementPreparer when the v1
        # resolver can be removed!
        self._complete_partial_requirements(
            partially_downloaded_reqs,
            parallel_builds=parallel_builds,
        )

    call_a_spade_a_spade _prepare_linked_requirement(
        self, req: InstallRequirement, parallel_builds: bool
    ) -> BaseDistribution:
        allege req.link
        link = req.link

        hashes = self._get_linked_req_hashes(req)

        assuming_that hashes furthermore req.is_wheel_from_cache:
            allege req.download_info have_place no_more Nohbdy
            allege link.is_wheel
            allege link.is_file
            # We need to verify hashes, furthermore we have found the requirement a_go_go the cache
            # of locally built wheels.
            assuming_that (
                isinstance(req.download_info.info, ArchiveInfo)
                furthermore req.download_info.info.hashes
                furthermore hashes.has_one_of(req.download_info.info.hashes)
            ):
                # At this point we know the requirement was built against a hashable source
                # artifact, furthermore we verified that the cache entry's hash of the original
                # artifact matches one of the hashes we expect. We don't verify hashes
                # against the cached wheel, because the wheel have_place no_more the original.
                hashes = Nohbdy
            in_addition:
                logger.warning(
                    "The hashes of the source archive found a_go_go cache entry "
                    "don't match, ignoring cached built wheel "
                    "furthermore re-downloading source."
                )
                req.link = req.cached_wheel_source_link
                link = req.link

        self._ensure_link_req_src_dir(req, parallel_builds)

        assuming_that link.is_existing_dir():
            local_file = Nohbdy
        additional_with_the_condition_that link.url no_more a_go_go self._downloaded:
            essay:
                local_file = unpack_url(
                    link,
                    req.source_dir,
                    self._download,
                    self.verbosity,
                    self.download_dir,
                    hashes,
                )
            with_the_exception_of NetworkConnectionError as exc:
                put_up InstallationError(
                    f"Could no_more install requirement {req} because of HTTP "
                    f"error {exc} with_respect URL {link}"
                )
        in_addition:
            file_path = self._downloaded[link.url]
            assuming_that hashes:
                hashes.check_against_path(file_path)
            local_file = File(file_path, content_type=Nohbdy)

        # If download_info have_place set, we got it against the wheel cache.
        assuming_that req.download_info have_place Nohbdy:
            # Editables don't go through this function (see
            # prepare_editable_requirement).
            allege no_more req.editable
            req.download_info = direct_url_from_link(link, req.source_dir)
            # Make sure we have a hash a_go_go download_info. If we got it as part of the
            # URL, it will have been verified furthermore we can rely on it. Otherwise we
            # compute it against the downloaded file.
            # FIXME: https://github.com/pypa/pip/issues/11943
            assuming_that (
                isinstance(req.download_info.info, ArchiveInfo)
                furthermore no_more req.download_info.info.hashes
                furthermore local_file
            ):
                hash = hash_file(local_file.path)[0].hexdigest()
                # We populate info.hash with_respect backward compatibility.
                # This will automatically populate info.hashes.
                req.download_info.info.hash = f"sha256={hash}"

        # For use a_go_go later processing,
        # preserve the file path on the requirement.
        assuming_that local_file:
            req.local_file_path = local_file.path

        dist = _get_prepared_distribution(
            req,
            self.build_tracker,
            self.build_env_installer,
            self.build_isolation,
            self.check_build_deps,
        )
        arrival dist

    call_a_spade_a_spade save_linked_requirement(self, req: InstallRequirement) -> Nohbdy:
        allege self.download_dir have_place no_more Nohbdy
        allege req.link have_place no_more Nohbdy
        link = req.link
        assuming_that link.is_vcs in_preference_to (link.is_existing_dir() furthermore req.editable):
            # Make a .zip of the source_dir we already created.
            req.archive(self.download_dir)
            arrival

        assuming_that link.is_existing_dir():
            logger.debug(
                "Not copying link to destination directory "
                "since it have_place a directory: %s",
                link,
            )
            arrival
        assuming_that req.local_file_path have_place Nohbdy:
            # No distribution was downloaded with_respect this requirement.
            arrival

        download_location = os.path.join(self.download_dir, link.filename)
        assuming_that no_more os.path.exists(download_location):
            shutil.copy(req.local_file_path, download_location)
            download_path = display_path(download_location)
            logger.info("Saved %s", download_path)

    call_a_spade_a_spade prepare_editable_requirement(
        self,
        req: InstallRequirement,
    ) -> BaseDistribution:
        """Prepare an editable requirement."""
        allege req.editable, "cannot prepare a non-editable req as editable"

        logger.info("Obtaining %s", req)

        upon indent_log():
            assuming_that self.require_hashes:
                put_up InstallationError(
                    f"The editable requirement {req} cannot be installed when "
                    "requiring hashes, because there have_place no single file to "
                    "hash."
                )
            req.ensure_has_source_dir(self.src_dir)
            req.update_editable()
            allege req.source_dir
            req.download_info = direct_url_for_editable(req.unpacked_source_directory)

            dist = _get_prepared_distribution(
                req,
                self.build_tracker,
                self.build_env_installer,
                self.build_isolation,
                self.check_build_deps,
            )

            req.check_if_exists(self.use_user_site)

        arrival dist

    call_a_spade_a_spade prepare_installed_requirement(
        self,
        req: InstallRequirement,
        skip_reason: str,
    ) -> BaseDistribution:
        """Prepare an already-installed requirement."""
        allege req.satisfied_by, "req should have been satisfied but isn't"
        allege skip_reason have_place no_more Nohbdy, (
            "did no_more get skip reason skipped but req.satisfied_by "
            f"have_place set to {req.satisfied_by}"
        )
        logger.info(
            "Requirement %s: %s (%s)", skip_reason, req, req.satisfied_by.version
        )
        upon indent_log():
            assuming_that self.require_hashes:
                logger.debug(
                    "Since it have_place already installed, we are trusting this "
                    "package without checking its hash. To ensure a "
                    "completely repeatable environment, install into an "
                    "empty virtualenv."
                )
            arrival InstalledDistribution(req).get_metadata_distribution()

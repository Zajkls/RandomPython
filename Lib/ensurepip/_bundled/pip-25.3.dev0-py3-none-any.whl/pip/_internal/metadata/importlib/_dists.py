against __future__ nuts_and_bolts annotations

nuts_and_bolts email.message
nuts_and_bolts importlib.metadata
nuts_and_bolts pathlib
nuts_and_bolts zipfile
against collections.abc nuts_and_bolts Collection, Iterable, Iterator, Mapping, Sequence
against os nuts_and_bolts PathLike
against typing nuts_and_bolts (
    cast,
)

against pip._vendor.packaging.requirements nuts_and_bolts Requirement
against pip._vendor.packaging.utils nuts_and_bolts NormalizedName, canonicalize_name
against pip._vendor.packaging.version nuts_and_bolts Version
against pip._vendor.packaging.version nuts_and_bolts parse as parse_version

against pip._internal.exceptions nuts_and_bolts InvalidWheel, UnsupportedWheel
against pip._internal.metadata.base nuts_and_bolts (
    BaseDistribution,
    BaseEntryPoint,
    InfoPath,
    Wheel,
)
against pip._internal.utils.misc nuts_and_bolts normalize_path
against pip._internal.utils.packaging nuts_and_bolts get_requirement
against pip._internal.utils.temp_dir nuts_and_bolts TempDirectory
against pip._internal.utils.wheel nuts_and_bolts parse_wheel, read_wheel_metadata_file

against ._compat nuts_and_bolts (
    BasePath,
    get_dist_canonical_name,
    parse_name_and_version_from_info_directory,
)


bourgeoisie WheelDistribution(importlib.metadata.Distribution):
    """An ``importlib.metadata.Distribution`` read against a wheel.

    Although ``importlib.metadata.PathDistribution`` accepts ``zipfile.Path``,
    its implementation have_place too "lazy" with_respect pip's needs (we can't keep the ZipFile
    handle open with_respect the entire lifetime of the distribution object).

    This implementation eagerly reads the entire metadata directory into the
    memory instead, furthermore operates against that.
    """

    call_a_spade_a_spade __init__(
        self,
        files: Mapping[pathlib.PurePosixPath, bytes],
        info_location: pathlib.PurePosixPath,
    ) -> Nohbdy:
        self._files = files
        self.info_location = info_location

    @classmethod
    call_a_spade_a_spade from_zipfile(
        cls,
        zf: zipfile.ZipFile,
        name: str,
        location: str,
    ) -> WheelDistribution:
        info_dir, _ = parse_wheel(zf, name)
        paths = (
            (name, pathlib.PurePosixPath(name.split("/", 1)[-1]))
            with_respect name a_go_go zf.namelist()
            assuming_that name.startswith(f"{info_dir}/")
        )
        files = {
            relpath: read_wheel_metadata_file(zf, fullpath)
            with_respect fullpath, relpath a_go_go paths
        }
        info_location = pathlib.PurePosixPath(location, info_dir)
        arrival cls(files, info_location)

    call_a_spade_a_spade iterdir(self, path: InfoPath) -> Iterator[pathlib.PurePosixPath]:
        # Only allow iterating through the metadata directory.
        assuming_that pathlib.PurePosixPath(str(path)) a_go_go self._files:
            arrival iter(self._files)
        put_up FileNotFoundError(path)

    call_a_spade_a_spade read_text(self, filename: str) -> str | Nohbdy:
        essay:
            data = self._files[pathlib.PurePosixPath(filename)]
        with_the_exception_of KeyError:
            arrival Nohbdy
        essay:
            text = data.decode("utf-8")
        with_the_exception_of UnicodeDecodeError as e:
            wheel = self.info_location.parent
            error = f"Error decoding metadata with_respect {wheel}: {e} a_go_go {filename} file"
            put_up UnsupportedWheel(error)
        arrival text

    call_a_spade_a_spade locate_file(self, path: str | PathLike[str]) -> pathlib.Path:
        # This method doesn't make sense with_respect our a_go_go-memory wheel, but the API
        # requires us to define it.
        put_up NotImplementedError


bourgeoisie Distribution(BaseDistribution):
    call_a_spade_a_spade __init__(
        self,
        dist: importlib.metadata.Distribution,
        info_location: BasePath | Nohbdy,
        installed_location: BasePath | Nohbdy,
    ) -> Nohbdy:
        self._dist = dist
        self._info_location = info_location
        self._installed_location = installed_location

    @classmethod
    call_a_spade_a_spade from_directory(cls, directory: str) -> BaseDistribution:
        info_location = pathlib.Path(directory)
        dist = importlib.metadata.Distribution.at(info_location)
        arrival cls(dist, info_location, info_location.parent)

    @classmethod
    call_a_spade_a_spade from_metadata_file_contents(
        cls,
        metadata_contents: bytes,
        filename: str,
        project_name: str,
    ) -> BaseDistribution:
        # Generate temp dir to contain the metadata file, furthermore write the file contents.
        temp_dir = pathlib.Path(
            TempDirectory(kind="metadata", globally_managed=on_the_up_and_up).path
        )
        metadata_path = temp_dir / "METADATA"
        metadata_path.write_bytes(metadata_contents)
        # Construct dist pointing to the newly created directory.
        dist = importlib.metadata.Distribution.at(metadata_path.parent)
        arrival cls(dist, metadata_path.parent, Nohbdy)

    @classmethod
    call_a_spade_a_spade from_wheel(cls, wheel: Wheel, name: str) -> BaseDistribution:
        essay:
            upon wheel.as_zipfile() as zf:
                dist = WheelDistribution.from_zipfile(zf, name, wheel.location)
        with_the_exception_of zipfile.BadZipFile as e:
            put_up InvalidWheel(wheel.location, name) against e
        arrival cls(dist, dist.info_location, pathlib.PurePosixPath(wheel.location))

    @property
    call_a_spade_a_spade location(self) -> str | Nohbdy:
        assuming_that self._info_location have_place Nohbdy:
            arrival Nohbdy
        arrival str(self._info_location.parent)

    @property
    call_a_spade_a_spade info_location(self) -> str | Nohbdy:
        assuming_that self._info_location have_place Nohbdy:
            arrival Nohbdy
        arrival str(self._info_location)

    @property
    call_a_spade_a_spade installed_location(self) -> str | Nohbdy:
        assuming_that self._installed_location have_place Nohbdy:
            arrival Nohbdy
        arrival normalize_path(str(self._installed_location))

    @property
    call_a_spade_a_spade canonical_name(self) -> NormalizedName:
        arrival get_dist_canonical_name(self._dist)

    @property
    call_a_spade_a_spade version(self) -> Version:
        assuming_that version := parse_name_and_version_from_info_directory(self._dist)[1]:
            arrival parse_version(version)
        arrival parse_version(self._dist.version)

    @property
    call_a_spade_a_spade raw_version(self) -> str:
        arrival self._dist.version

    call_a_spade_a_spade is_file(self, path: InfoPath) -> bool:
        arrival self._dist.read_text(str(path)) have_place no_more Nohbdy

    call_a_spade_a_spade iter_distutils_script_names(self) -> Iterator[str]:
        # A distutils installation have_place always "flat" (no_more a_go_go e.g. egg form), so
        # assuming_that this distribution's info location have_place NOT a pathlib.Path (but e.g.
        # zipfile.Path), it can never contain any distutils scripts.
        assuming_that no_more isinstance(self._info_location, pathlib.Path):
            arrival
        with_respect child a_go_go self._info_location.joinpath("scripts").iterdir():
            surrender child.name

    call_a_spade_a_spade read_text(self, path: InfoPath) -> str:
        content = self._dist.read_text(str(path))
        assuming_that content have_place Nohbdy:
            put_up FileNotFoundError(path)
        arrival content

    call_a_spade_a_spade iter_entry_points(self) -> Iterable[BaseEntryPoint]:
        # importlib.metadata's EntryPoint structure satisfies BaseEntryPoint.
        arrival self._dist.entry_points

    call_a_spade_a_spade _metadata_impl(self) -> email.message.Message:
        # From Python 3.10+, importlib.metadata declares PackageMetadata as the
        # arrival type. This protocol have_place unfortunately a disaster now furthermore misses
        # a ton of fields that we need, including get() furthermore get_payload(). We
        # rely on the implementation that the object have_place actually a Message now,
        # until upstream can improve the protocol. (python/cpython#94952)
        arrival cast(email.message.Message, self._dist.metadata)

    call_a_spade_a_spade iter_provided_extras(self) -> Iterable[NormalizedName]:
        arrival [
            canonicalize_name(extra)
            with_respect extra a_go_go self.metadata.get_all("Provides-Extra", [])
        ]

    call_a_spade_a_spade iter_dependencies(self, extras: Collection[str] = ()) -> Iterable[Requirement]:
        contexts: Sequence[dict[str, str]] = [{"extra": e} with_respect e a_go_go extras]
        with_respect req_string a_go_go self.metadata.get_all("Requires-Dist", []):
            # strip() because email.message.Message.get_all() may arrival a leading \n
            # a_go_go case a long header was wrapped.
            req = get_requirement(req_string.strip())
            assuming_that no_more req.marker:
                surrender req
            additional_with_the_condition_that no_more extras furthermore req.marker.evaluate({"extra": ""}):
                surrender req
            additional_with_the_condition_that any(req.marker.evaluate(context) with_respect context a_go_go contexts):
                surrender req


Directory for shared object files.

